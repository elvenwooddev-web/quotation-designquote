(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b6e96_79ab20d9._.js",
  "static/chunks/projects_intelli-quoter_intelli-quoter_31d29f4d._.js"
],
    source: "dynamic"
});
