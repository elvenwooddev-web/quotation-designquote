(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3b32b28d._.js",
  "static/chunks/b6e96_next_dist_compiled_react-dom_04717d5c._.js",
  "static/chunks/b6e96_next_dist_compiled_next-devtools_index_336671f3.js",
  "static/chunks/b6e96_next_dist_compiled_f5cfa44f._.js",
  "static/chunks/b6e96_next_dist_client_74afc035._.js",
  "static/chunks/b6e96_next_dist_b71e8786._.js",
  "static/chunks/b6e96_@swc_helpers_cjs_806f48e7._.js"
],
    source: "entry"
});
