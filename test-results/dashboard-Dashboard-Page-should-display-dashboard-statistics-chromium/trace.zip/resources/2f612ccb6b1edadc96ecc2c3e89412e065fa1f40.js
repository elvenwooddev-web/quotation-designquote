(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/projects/intelli-quoter/intelli-quoter/node_modules/@supabase/node-fetch/browser.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/projects/intelli-quoter/intelli-quoter/node_modules/@supabase/node-fetch/browser.js [app-client] (ecmascript)");
    });
});
}),
]);