(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__df764d2b._.css",
  "static/chunks/b6e96_@supabase_node-fetch_browser_ce86f77b.js",
  "static/chunks/b6e96_93cbca34._.js",
  "static/chunks/projects_intelli-quoter_intelli-quoter_ce1404c1._.js"
],
    source: "dynamic"
});
