(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/projects_intelli-quoter_intelli-quoter_820f0a22._.js"
],
    source: "dynamic"
});
