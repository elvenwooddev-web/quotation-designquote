(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/projects_intelli-quoter_intelli-quoter_a62a7038._.js",
  "static/chunks/b6e96_lucide-react_dist_esm_icons_97b70e51._.js"
],
    source: "dynamic"
});
